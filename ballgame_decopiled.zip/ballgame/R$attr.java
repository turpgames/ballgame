// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.turpgames.ballgame;


// Referenced classes of package com.turpgames.ballgame:
//            R

public static final class 
{

    public static final int adSize = 0x7f010000;
    public static final int adSizes = 0x7f010001;
    public static final int adUnitId = 0x7f010002;
    public static final int cameraBearing = 0x7f010004;
    public static final int cameraTargetLat = 0x7f010005;
    public static final int cameraTargetLng = 0x7f010006;
    public static final int cameraTilt = 0x7f010007;
    public static final int cameraZoom = 0x7f010008;
    public static final int confirm_logout = 0x7f01001d;
    public static final int done_button_background = 0x7f010017;
    public static final int done_button_text = 0x7f010015;
    public static final int extra_fields = 0x7f010012;
    public static final int fetch_user_info = 0x7f01001e;
    public static final int is_cropped = 0x7f010022;
    public static final int login_text = 0x7f01001f;
    public static final int logout_text = 0x7f010020;
    public static final int mapType = 0x7f010003;
    public static final int multi_select = 0x7f010018;
    public static final int preset_size = 0x7f010021;
    public static final int radius_in_meters = 0x7f010019;
    public static final int results_limit = 0x7f01001a;
    public static final int search_text = 0x7f01001b;
    public static final int show_pictures = 0x7f010011;
    public static final int show_search_box = 0x7f01001c;
    public static final int show_title_bar = 0x7f010013;
    public static final int title_bar_background = 0x7f010016;
    public static final int title_text = 0x7f010014;
    public static final int uiCompass = 0x7f010009;
    public static final int uiRotateGestures = 0x7f01000a;
    public static final int uiScrollGestures = 0x7f01000b;
    public static final int uiTiltGestures = 0x7f01000c;
    public static final int uiZoomControls = 0x7f01000d;
    public static final int uiZoomGestures = 0x7f01000e;
    public static final int useViewLifecycle = 0x7f01000f;
    public static final int zOrderOnTop = 0x7f010010;

    public ()
    {
    }
}
