// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.turpgames.ballgame;


// Referenced classes of package com.turpgames.ballgame:
//            R

public static final class 
{

    public static final int com_facebook_loginview_compound_drawable_padding = 0x7f090008;
    public static final int com_facebook_loginview_padding_bottom = 0x7f090007;
    public static final int com_facebook_loginview_padding_left = 0x7f090004;
    public static final int com_facebook_loginview_padding_right = 0x7f090005;
    public static final int com_facebook_loginview_padding_top = 0x7f090006;
    public static final int com_facebook_loginview_text_size = 0x7f090009;
    public static final int com_facebook_picker_divider_width = 0x7f090001;
    public static final int com_facebook_picker_place_image_size = 0x7f090000;
    public static final int com_facebook_profilepictureview_preset_size_large = 0x7f09000c;
    public static final int com_facebook_profilepictureview_preset_size_normal = 0x7f09000b;
    public static final int com_facebook_profilepictureview_preset_size_small = 0x7f09000a;
    public static final int com_facebook_tooltip_horizontal_padding = 0x7f09000d;
    public static final int com_facebook_usersettingsfragment_profile_picture_height = 0x7f090003;
    public static final int com_facebook_usersettingsfragment_profile_picture_width = 0x7f090002;

    public ()
    {
    }
}
