// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.turpgames.ballgame;


public final class R
{
    public static final class attr
    {

        public static final int adSize = 0x7f010000;
        public static final int adSizes = 0x7f010001;
        public static final int adUnitId = 0x7f010002;
        public static final int cameraBearing = 0x7f010004;
        public static final int cameraTargetLat = 0x7f010005;
        public static final int cameraTargetLng = 0x7f010006;
        public static final int cameraTilt = 0x7f010007;
        public static final int cameraZoom = 0x7f010008;
        public static final int confirm_logout = 0x7f01001d;
        public static final int done_button_background = 0x7f010017;
        public static final int done_button_text = 0x7f010015;
        public static final int extra_fields = 0x7f010012;
        public static final int fetch_user_info = 0x7f01001e;
        public static final int is_cropped = 0x7f010022;
        public static final int login_text = 0x7f01001f;
        public static final int logout_text = 0x7f010020;
        public static final int mapType = 0x7f010003;
        public static final int multi_select = 0x7f010018;
        public static final int preset_size = 0x7f010021;
        public static final int radius_in_meters = 0x7f010019;
        public static final int results_limit = 0x7f01001a;
        public static final int search_text = 0x7f01001b;
        public static final int show_pictures = 0x7f010011;
        public static final int show_search_box = 0x7f01001c;
        public static final int show_title_bar = 0x7f010013;
        public static final int title_bar_background = 0x7f010016;
        public static final int title_text = 0x7f010014;
        public static final int uiCompass = 0x7f010009;
        public static final int uiRotateGestures = 0x7f01000a;
        public static final int uiScrollGestures = 0x7f01000b;
        public static final int uiTiltGestures = 0x7f01000c;
        public static final int uiZoomControls = 0x7f01000d;
        public static final int uiZoomGestures = 0x7f01000e;
        public static final int useViewLifecycle = 0x7f01000f;
        public static final int zOrderOnTop = 0x7f010010;

        public attr()
        {
        }
    }

    public static final class color
    {

        public static final int com_facebook_blue = 0x7f05000c;
        public static final int com_facebook_loginview_text_color = 0x7f050010;
        public static final int com_facebook_picker_search_bar_background = 0x7f05000a;
        public static final int com_facebook_picker_search_bar_text = 0x7f05000b;
        public static final int com_facebook_usersettingsfragment_connected_shadow_color = 0x7f05000e;
        public static final int com_facebook_usersettingsfragment_connected_text_color = 0x7f05000d;
        public static final int com_facebook_usersettingsfragment_not_connected_text_color = 0x7f05000f;
        public static final int common_action_bar_splitter = 0x7f050009;
        public static final int common_signin_btn_dark_text_default = 0x7f050000;
        public static final int common_signin_btn_dark_text_disabled = 0x7f050002;
        public static final int common_signin_btn_dark_text_focused = 0x7f050003;
        public static final int common_signin_btn_dark_text_pressed = 0x7f050001;
        public static final int common_signin_btn_default_background = 0x7f050008;
        public static final int common_signin_btn_light_text_default = 0x7f050004;
        public static final int common_signin_btn_light_text_disabled = 0x7f050006;
        public static final int common_signin_btn_light_text_focused = 0x7f050007;
        public static final int common_signin_btn_light_text_pressed = 0x7f050005;
        public static final int common_signin_btn_text_dark = 0x7f050011;
        public static final int common_signin_btn_text_light = 0x7f050012;

        public color()
        {
        }
    }

    public static final class dimen
    {

        public static final int com_facebook_loginview_compound_drawable_padding = 0x7f090008;
        public static final int com_facebook_loginview_padding_bottom = 0x7f090007;
        public static final int com_facebook_loginview_padding_left = 0x7f090004;
        public static final int com_facebook_loginview_padding_right = 0x7f090005;
        public static final int com_facebook_loginview_padding_top = 0x7f090006;
        public static final int com_facebook_loginview_text_size = 0x7f090009;
        public static final int com_facebook_picker_divider_width = 0x7f090001;
        public static final int com_facebook_picker_place_image_size = 0x7f090000;
        public static final int com_facebook_profilepictureview_preset_size_large = 0x7f09000c;
        public static final int com_facebook_profilepictureview_preset_size_normal = 0x7f09000b;
        public static final int com_facebook_profilepictureview_preset_size_small = 0x7f09000a;
        public static final int com_facebook_tooltip_horizontal_padding = 0x7f09000d;
        public static final int com_facebook_usersettingsfragment_profile_picture_height = 0x7f090003;
        public static final int com_facebook_usersettingsfragment_profile_picture_width = 0x7f090002;

        public dimen()
        {
        }
    }

    public static final class drawable
    {

        public static final int com_facebook_button_blue = 0x7f020000;
        public static final int com_facebook_button_blue_focused = 0x7f020001;
        public static final int com_facebook_button_blue_normal = 0x7f020002;
        public static final int com_facebook_button_blue_pressed = 0x7f020003;
        public static final int com_facebook_button_check = 0x7f020004;
        public static final int com_facebook_button_check_off = 0x7f020005;
        public static final int com_facebook_button_check_on = 0x7f020006;
        public static final int com_facebook_button_grey_focused = 0x7f020007;
        public static final int com_facebook_button_grey_normal = 0x7f020008;
        public static final int com_facebook_button_grey_pressed = 0x7f020009;
        public static final int com_facebook_close = 0x7f02000a;
        public static final int com_facebook_inverse_icon = 0x7f02000b;
        public static final int com_facebook_list_divider = 0x7f02000c;
        public static final int com_facebook_list_section_header_background = 0x7f02000d;
        public static final int com_facebook_loginbutton_silver = 0x7f02000e;
        public static final int com_facebook_logo = 0x7f02000f;
        public static final int com_facebook_picker_default_separator_color = 0x7f020045;
        public static final int com_facebook_picker_item_background = 0x7f020010;
        public static final int com_facebook_picker_list_focused = 0x7f020011;
        public static final int com_facebook_picker_list_longpressed = 0x7f020012;
        public static final int com_facebook_picker_list_pressed = 0x7f020013;
        public static final int com_facebook_picker_list_selector = 0x7f020014;
        public static final int com_facebook_picker_list_selector_background_transition = 0x7f020015;
        public static final int com_facebook_picker_list_selector_disabled = 0x7f020016;
        public static final int com_facebook_picker_magnifier = 0x7f020017;
        public static final int com_facebook_picker_top_button = 0x7f020018;
        public static final int com_facebook_place_default_icon = 0x7f020019;
        public static final int com_facebook_profile_default_icon = 0x7f02001a;
        public static final int com_facebook_profile_picture_blank_portrait = 0x7f02001b;
        public static final int com_facebook_profile_picture_blank_square = 0x7f02001c;
        public static final int com_facebook_tooltip_black_background = 0x7f02001d;
        public static final int com_facebook_tooltip_black_bottomnub = 0x7f02001e;
        public static final int com_facebook_tooltip_black_topnub = 0x7f02001f;
        public static final int com_facebook_tooltip_black_xout = 0x7f020020;
        public static final int com_facebook_tooltip_blue_background = 0x7f020021;
        public static final int com_facebook_tooltip_blue_bottomnub = 0x7f020022;
        public static final int com_facebook_tooltip_blue_topnub = 0x7f020023;
        public static final int com_facebook_tooltip_blue_xout = 0x7f020024;
        public static final int com_facebook_top_background = 0x7f020025;
        public static final int com_facebook_top_button = 0x7f020026;
        public static final int com_facebook_usersettingsfragment_background_gradient = 0x7f020027;
        public static final int common_signin_btn_icon_dark = 0x7f020028;
        public static final int common_signin_btn_icon_disabled_dark = 0x7f020029;
        public static final int common_signin_btn_icon_disabled_focus_dark = 0x7f02002a;
        public static final int common_signin_btn_icon_disabled_focus_light = 0x7f02002b;
        public static final int common_signin_btn_icon_disabled_light = 0x7f02002c;
        public static final int common_signin_btn_icon_focus_dark = 0x7f02002d;
        public static final int common_signin_btn_icon_focus_light = 0x7f02002e;
        public static final int common_signin_btn_icon_light = 0x7f02002f;
        public static final int common_signin_btn_icon_normal_dark = 0x7f020030;
        public static final int common_signin_btn_icon_normal_light = 0x7f020031;
        public static final int common_signin_btn_icon_pressed_dark = 0x7f020032;
        public static final int common_signin_btn_icon_pressed_light = 0x7f020033;
        public static final int common_signin_btn_text_dark = 0x7f020034;
        public static final int common_signin_btn_text_disabled_dark = 0x7f020035;
        public static final int common_signin_btn_text_disabled_focus_dark = 0x7f020036;
        public static final int common_signin_btn_text_disabled_focus_light = 0x7f020037;
        public static final int common_signin_btn_text_disabled_light = 0x7f020038;
        public static final int common_signin_btn_text_focus_dark = 0x7f020039;
        public static final int common_signin_btn_text_focus_light = 0x7f02003a;
        public static final int common_signin_btn_text_light = 0x7f02003b;
        public static final int common_signin_btn_text_normal_dark = 0x7f02003c;
        public static final int common_signin_btn_text_normal_light = 0x7f02003d;
        public static final int common_signin_btn_text_pressed_dark = 0x7f02003e;
        public static final int common_signin_btn_text_pressed_light = 0x7f02003f;
        public static final int ic_launcher = 0x7f020040;
        public static final int ic_plusone_medium_off_client = 0x7f020041;
        public static final int ic_plusone_small_off_client = 0x7f020042;
        public static final int ic_plusone_standard_off_client = 0x7f020043;
        public static final int ic_plusone_tall_off_client = 0x7f020044;

        public drawable()
        {
        }
    }

    public static final class id
    {

        public static final int com_facebook_body_frame = 0x7f060019;
        public static final int com_facebook_button_xout = 0x7f06001b;
        public static final int com_facebook_login_activity_progress_bar = 0x7f060009;
        public static final int com_facebook_picker_activity_circle = 0x7f060008;
        public static final int com_facebook_picker_checkbox = 0x7f06000b;
        public static final int com_facebook_picker_checkbox_stub = 0x7f06000f;
        public static final int com_facebook_picker_divider = 0x7f060013;
        public static final int com_facebook_picker_done_button = 0x7f060012;
        public static final int com_facebook_picker_image = 0x7f06000c;
        public static final int com_facebook_picker_list_section_header = 0x7f060010;
        public static final int com_facebook_picker_list_view = 0x7f060007;
        public static final int com_facebook_picker_profile_pic_stub = 0x7f06000d;
        public static final int com_facebook_picker_row_activity_circle = 0x7f06000a;
        public static final int com_facebook_picker_search_text = 0x7f060018;
        public static final int com_facebook_picker_title = 0x7f06000e;
        public static final int com_facebook_picker_title_bar = 0x7f060015;
        public static final int com_facebook_picker_title_bar_stub = 0x7f060014;
        public static final int com_facebook_picker_top_bar = 0x7f060011;
        public static final int com_facebook_search_bar_view = 0x7f060017;
        public static final int com_facebook_tooltip_bubble_view_bottom_pointer = 0x7f06001d;
        public static final int com_facebook_tooltip_bubble_view_text_body = 0x7f06001c;
        public static final int com_facebook_tooltip_bubble_view_top_pointer = 0x7f06001a;
        public static final int com_facebook_usersettingsfragment_login_button = 0x7f060020;
        public static final int com_facebook_usersettingsfragment_logo_image = 0x7f06001e;
        public static final int com_facebook_usersettingsfragment_profile_name = 0x7f06001f;
        public static final int hybrid = 0x7f060004;
        public static final int large = 0x7f060006;
        public static final int none = 0x7f060000;
        public static final int normal = 0x7f060001;
        public static final int picker_subtitle = 0x7f060016;
        public static final int satellite = 0x7f060002;
        public static final int small = 0x7f060005;
        public static final int terrain = 0x7f060003;

        public id()
        {
        }
    }

    public static final class integer
    {

        public static final int google_play_services_version = 0x7f070000;

        public integer()
        {
        }
    }

    public static final class layout
    {

        public static final int com_facebook_friendpickerfragment = 0x7f030000;
        public static final int com_facebook_login_activity_layout = 0x7f030001;
        public static final int com_facebook_picker_activity_circle_row = 0x7f030002;
        public static final int com_facebook_picker_checkbox = 0x7f030003;
        public static final int com_facebook_picker_image = 0x7f030004;
        public static final int com_facebook_picker_list_row = 0x7f030005;
        public static final int com_facebook_picker_list_section_header = 0x7f030006;
        public static final int com_facebook_picker_search_box = 0x7f030007;
        public static final int com_facebook_picker_title_bar = 0x7f030008;
        public static final int com_facebook_picker_title_bar_stub = 0x7f030009;
        public static final int com_facebook_placepickerfragment = 0x7f03000a;
        public static final int com_facebook_placepickerfragment_list_row = 0x7f03000b;
        public static final int com_facebook_search_bar_layout = 0x7f03000c;
        public static final int com_facebook_tooltip_bubble = 0x7f03000d;
        public static final int com_facebook_usersettingsfragment = 0x7f03000e;

        public layout()
        {
        }
    }

    public static final class string
    {

        public static final int app_id = 0x7f040036;
        public static final int app_name = 0x7f040000;
        public static final int auth_client_needs_enabling_title = 0x7f040016;
        public static final int auth_client_needs_installation_title = 0x7f040017;
        public static final int auth_client_needs_update_title = 0x7f040018;
        public static final int auth_client_play_services_err_notification_msg = 0x7f040019;
        public static final int auth_client_requested_by_msg = 0x7f04001a;
        public static final int auth_client_using_bad_version_title = 0x7f040015;
        public static final int com_facebook_choose_friends = 0x7f04002b;
        public static final int com_facebook_dialogloginactivity_ok_button = 0x7f04001c;
        public static final int com_facebook_internet_permission_error_message = 0x7f04002f;
        public static final int com_facebook_internet_permission_error_title = 0x7f04002e;
        public static final int com_facebook_loading = 0x7f04002d;
        public static final int com_facebook_loginview_cancel_action = 0x7f040022;
        public static final int com_facebook_loginview_log_in_button = 0x7f04001e;
        public static final int com_facebook_loginview_log_out_action = 0x7f040021;
        public static final int com_facebook_loginview_log_out_button = 0x7f04001d;
        public static final int com_facebook_loginview_logged_in_as = 0x7f04001f;
        public static final int com_facebook_loginview_logged_in_using_facebook = 0x7f040020;
        public static final int com_facebook_logo_content_description = 0x7f040023;
        public static final int com_facebook_nearby = 0x7f04002c;
        public static final int com_facebook_picker_done_button_text = 0x7f04002a;
        public static final int com_facebook_placepicker_subtitle_catetory_only_format = 0x7f040028;
        public static final int com_facebook_placepicker_subtitle_format = 0x7f040027;
        public static final int com_facebook_placepicker_subtitle_were_here_only_format = 0x7f040029;
        public static final int com_facebook_requesterror_password_changed = 0x7f040032;
        public static final int com_facebook_requesterror_permissions = 0x7f040034;
        public static final int com_facebook_requesterror_reconnect = 0x7f040033;
        public static final int com_facebook_requesterror_relogin = 0x7f040031;
        public static final int com_facebook_requesterror_web_login = 0x7f040030;
        public static final int com_facebook_tooltip_default = 0x7f040035;
        public static final int com_facebook_usersettingsfragment_log_in_button = 0x7f040024;
        public static final int com_facebook_usersettingsfragment_logged_in = 0x7f040025;
        public static final int com_facebook_usersettingsfragment_not_logged_in = 0x7f040026;
        public static final int common_google_play_services_enable_button = 0x7f040007;
        public static final int common_google_play_services_enable_text = 0x7f040006;
        public static final int common_google_play_services_enable_title = 0x7f040005;
        public static final int common_google_play_services_install_button = 0x7f040004;
        public static final int common_google_play_services_install_text_phone = 0x7f040002;
        public static final int common_google_play_services_install_text_tablet = 0x7f040003;
        public static final int common_google_play_services_install_title = 0x7f040001;
        public static final int common_google_play_services_invalid_account_text = 0x7f04000d;
        public static final int common_google_play_services_invalid_account_title = 0x7f04000c;
        public static final int common_google_play_services_network_error_text = 0x7f04000b;
        public static final int common_google_play_services_network_error_title = 0x7f04000a;
        public static final int common_google_play_services_unknown_issue = 0x7f04000e;
        public static final int common_google_play_services_unsupported_date_text = 0x7f040011;
        public static final int common_google_play_services_unsupported_text = 0x7f040010;
        public static final int common_google_play_services_unsupported_title = 0x7f04000f;
        public static final int common_google_play_services_update_button = 0x7f040012;
        public static final int common_google_play_services_update_text = 0x7f040009;
        public static final int common_google_play_services_update_title = 0x7f040008;
        public static final int common_signin_button_text = 0x7f040013;
        public static final int common_signin_button_text_long = 0x7f040014;
        public static final int location_client_powered_by_google = 0x7f04001b;

        public string()
        {
        }
    }

    public static final class style
    {

        public static final int AppBaseTheme = 0x7f080000;
        public static final int AppTheme = 0x7f080001;
        public static final int GdxTheme = 0x7f080005;
        public static final int com_facebook_loginview_default_style = 0x7f080002;
        public static final int com_facebook_loginview_silver_style = 0x7f080003;
        public static final int tooltip_bubble_text = 0x7f080004;

        public style()
        {
        }
    }

    public static final class styleable
    {

        public static final int AdsAttrs[] = {
            0x7f010000, 0x7f010001, 0x7f010002
        };
        public static final int AdsAttrs_adSize = 0;
        public static final int AdsAttrs_adSizes = 1;
        public static final int AdsAttrs_adUnitId = 2;
        public static final int MapAttrs[] = {
            0x7f010003, 0x7f010004, 0x7f010005, 0x7f010006, 0x7f010007, 0x7f010008, 0x7f010009, 0x7f01000a, 0x7f01000b, 0x7f01000c, 
            0x7f01000d, 0x7f01000e, 0x7f01000f, 0x7f010010
        };
        public static final int MapAttrs_cameraBearing = 1;
        public static final int MapAttrs_cameraTargetLat = 2;
        public static final int MapAttrs_cameraTargetLng = 3;
        public static final int MapAttrs_cameraTilt = 4;
        public static final int MapAttrs_cameraZoom = 5;
        public static final int MapAttrs_mapType = 0;
        public static final int MapAttrs_uiCompass = 6;
        public static final int MapAttrs_uiRotateGestures = 7;
        public static final int MapAttrs_uiScrollGestures = 8;
        public static final int MapAttrs_uiTiltGestures = 9;
        public static final int MapAttrs_uiZoomControls = 10;
        public static final int MapAttrs_uiZoomGestures = 11;
        public static final int MapAttrs_useViewLifecycle = 12;
        public static final int MapAttrs_zOrderOnTop = 13;
        public static final int com_facebook_friend_picker_fragment[] = {
            0x7f010018
        };
        public static final int com_facebook_friend_picker_fragment_multi_select = 0;
        public static final int com_facebook_login_view[] = {
            0x7f01001d, 0x7f01001e, 0x7f01001f, 0x7f010020
        };
        public static final int com_facebook_login_view_confirm_logout = 0;
        public static final int com_facebook_login_view_fetch_user_info = 1;
        public static final int com_facebook_login_view_login_text = 2;
        public static final int com_facebook_login_view_logout_text = 3;
        public static final int com_facebook_picker_fragment[] = {
            0x7f010011, 0x7f010012, 0x7f010013, 0x7f010014, 0x7f010015, 0x7f010016, 0x7f010017
        };
        public static final int com_facebook_picker_fragment_done_button_background = 6;
        public static final int com_facebook_picker_fragment_done_button_text = 4;
        public static final int com_facebook_picker_fragment_extra_fields = 1;
        public static final int com_facebook_picker_fragment_show_pictures = 0;
        public static final int com_facebook_picker_fragment_show_title_bar = 2;
        public static final int com_facebook_picker_fragment_title_bar_background = 5;
        public static final int com_facebook_picker_fragment_title_text = 3;
        public static final int com_facebook_place_picker_fragment[] = {
            0x7f010019, 0x7f01001a, 0x7f01001b, 0x7f01001c
        };
        public static final int com_facebook_place_picker_fragment_radius_in_meters = 0;
        public static final int com_facebook_place_picker_fragment_results_limit = 1;
        public static final int com_facebook_place_picker_fragment_search_text = 2;
        public static final int com_facebook_place_picker_fragment_show_search_box = 3;
        public static final int com_facebook_profile_picture_view[] = {
            0x7f010021, 0x7f010022
        };
        public static final int com_facebook_profile_picture_view_is_cropped = 1;
        public static final int com_facebook_profile_picture_view_preset_size;


        public styleable()
        {
        }
    }


    public R()
    {
    }
}
