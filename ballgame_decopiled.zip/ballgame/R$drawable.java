// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.turpgames.ballgame;


// Referenced classes of package com.turpgames.ballgame:
//            R

public static final class 
{

    public static final int com_facebook_button_blue = 0x7f020000;
    public static final int com_facebook_button_blue_focused = 0x7f020001;
    public static final int com_facebook_button_blue_normal = 0x7f020002;
    public static final int com_facebook_button_blue_pressed = 0x7f020003;
    public static final int com_facebook_button_check = 0x7f020004;
    public static final int com_facebook_button_check_off = 0x7f020005;
    public static final int com_facebook_button_check_on = 0x7f020006;
    public static final int com_facebook_button_grey_focused = 0x7f020007;
    public static final int com_facebook_button_grey_normal = 0x7f020008;
    public static final int com_facebook_button_grey_pressed = 0x7f020009;
    public static final int com_facebook_close = 0x7f02000a;
    public static final int com_facebook_inverse_icon = 0x7f02000b;
    public static final int com_facebook_list_divider = 0x7f02000c;
    public static final int com_facebook_list_section_header_background = 0x7f02000d;
    public static final int com_facebook_loginbutton_silver = 0x7f02000e;
    public static final int com_facebook_logo = 0x7f02000f;
    public static final int com_facebook_picker_default_separator_color = 0x7f020045;
    public static final int com_facebook_picker_item_background = 0x7f020010;
    public static final int com_facebook_picker_list_focused = 0x7f020011;
    public static final int com_facebook_picker_list_longpressed = 0x7f020012;
    public static final int com_facebook_picker_list_pressed = 0x7f020013;
    public static final int com_facebook_picker_list_selector = 0x7f020014;
    public static final int com_facebook_picker_list_selector_background_transition = 0x7f020015;
    public static final int com_facebook_picker_list_selector_disabled = 0x7f020016;
    public static final int com_facebook_picker_magnifier = 0x7f020017;
    public static final int com_facebook_picker_top_button = 0x7f020018;
    public static final int com_facebook_place_default_icon = 0x7f020019;
    public static final int com_facebook_profile_default_icon = 0x7f02001a;
    public static final int com_facebook_profile_picture_blank_portrait = 0x7f02001b;
    public static final int com_facebook_profile_picture_blank_square = 0x7f02001c;
    public static final int com_facebook_tooltip_black_background = 0x7f02001d;
    public static final int com_facebook_tooltip_black_bottomnub = 0x7f02001e;
    public static final int com_facebook_tooltip_black_topnub = 0x7f02001f;
    public static final int com_facebook_tooltip_black_xout = 0x7f020020;
    public static final int com_facebook_tooltip_blue_background = 0x7f020021;
    public static final int com_facebook_tooltip_blue_bottomnub = 0x7f020022;
    public static final int com_facebook_tooltip_blue_topnub = 0x7f020023;
    public static final int com_facebook_tooltip_blue_xout = 0x7f020024;
    public static final int com_facebook_top_background = 0x7f020025;
    public static final int com_facebook_top_button = 0x7f020026;
    public static final int com_facebook_usersettingsfragment_background_gradient = 0x7f020027;
    public static final int common_signin_btn_icon_dark = 0x7f020028;
    public static final int common_signin_btn_icon_disabled_dark = 0x7f020029;
    public static final int common_signin_btn_icon_disabled_focus_dark = 0x7f02002a;
    public static final int common_signin_btn_icon_disabled_focus_light = 0x7f02002b;
    public static final int common_signin_btn_icon_disabled_light = 0x7f02002c;
    public static final int common_signin_btn_icon_focus_dark = 0x7f02002d;
    public static final int common_signin_btn_icon_focus_light = 0x7f02002e;
    public static final int common_signin_btn_icon_light = 0x7f02002f;
    public static final int common_signin_btn_icon_normal_dark = 0x7f020030;
    public static final int common_signin_btn_icon_normal_light = 0x7f020031;
    public static final int common_signin_btn_icon_pressed_dark = 0x7f020032;
    public static final int common_signin_btn_icon_pressed_light = 0x7f020033;
    public static final int common_signin_btn_text_dark = 0x7f020034;
    public static final int common_signin_btn_text_disabled_dark = 0x7f020035;
    public static final int common_signin_btn_text_disabled_focus_dark = 0x7f020036;
    public static final int common_signin_btn_text_disabled_focus_light = 0x7f020037;
    public static final int common_signin_btn_text_disabled_light = 0x7f020038;
    public static final int common_signin_btn_text_focus_dark = 0x7f020039;
    public static final int common_signin_btn_text_focus_light = 0x7f02003a;
    public static final int common_signin_btn_text_light = 0x7f02003b;
    public static final int common_signin_btn_text_normal_dark = 0x7f02003c;
    public static final int common_signin_btn_text_normal_light = 0x7f02003d;
    public static final int common_signin_btn_text_pressed_dark = 0x7f02003e;
    public static final int common_signin_btn_text_pressed_light = 0x7f02003f;
    public static final int ic_launcher = 0x7f020040;
    public static final int ic_plusone_medium_off_client = 0x7f020041;
    public static final int ic_plusone_small_off_client = 0x7f020042;
    public static final int ic_plusone_standard_off_client = 0x7f020043;
    public static final int ic_plusone_tall_off_client = 0x7f020044;

    public ()
    {
    }
}
