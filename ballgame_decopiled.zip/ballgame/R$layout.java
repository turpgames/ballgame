// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.turpgames.ballgame;


// Referenced classes of package com.turpgames.ballgame:
//            R

public static final class 
{

    public static final int com_facebook_friendpickerfragment = 0x7f030000;
    public static final int com_facebook_login_activity_layout = 0x7f030001;
    public static final int com_facebook_picker_activity_circle_row = 0x7f030002;
    public static final int com_facebook_picker_checkbox = 0x7f030003;
    public static final int com_facebook_picker_image = 0x7f030004;
    public static final int com_facebook_picker_list_row = 0x7f030005;
    public static final int com_facebook_picker_list_section_header = 0x7f030006;
    public static final int com_facebook_picker_search_box = 0x7f030007;
    public static final int com_facebook_picker_title_bar = 0x7f030008;
    public static final int com_facebook_picker_title_bar_stub = 0x7f030009;
    public static final int com_facebook_placepickerfragment = 0x7f03000a;
    public static final int com_facebook_placepickerfragment_list_row = 0x7f03000b;
    public static final int com_facebook_search_bar_layout = 0x7f03000c;
    public static final int com_facebook_tooltip_bubble = 0x7f03000d;
    public static final int com_facebook_usersettingsfragment = 0x7f03000e;

    public ()
    {
    }
}
