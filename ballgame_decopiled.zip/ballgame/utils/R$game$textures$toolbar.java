// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.turpgames.ballgame.utils;


// Referenced classes of package com.turpgames.ballgame.utils:
//            R

public static final class 
{

    public static final String back = "tb_back";
    public static final String musicPlay = "tb_music_play";
    public static final String musicStop = "tb_music_stop";
    public static final String settings = "tb_settings";
    public static final String soundOff = "tb_sound_off";
    public static final String soundOn = "tb_sound_on";
    public static final String vibrationOff = "tb_vibration_off";
    public static final String vibrationOn = "tb_vibration_on";

    public ()
    {
    }
}
