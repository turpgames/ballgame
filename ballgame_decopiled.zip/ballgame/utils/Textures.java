// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.turpgames.ballgame.utils;

import com.turpgames.framework.v0.IResourceManager;
import com.turpgames.framework.v0.ITexture;
import com.turpgames.framework.v0.util.Game;

public class Textures
{

    public static final ITexture ball_blue = Game.getResourceManager().getTexture("ball_blue");
    public static final ITexture bg = Game.getResourceManager().getTexture("bg");
    public static final ITexture tap_bottom = Game.getResourceManager().getTexture("tap_bottom");
    public static final ITexture tap_left = Game.getResourceManager().getTexture("tap_left");
    public static final ITexture tap_right = Game.getResourceManager().getTexture("tap_right");

    public Textures()
    {
    }

}
