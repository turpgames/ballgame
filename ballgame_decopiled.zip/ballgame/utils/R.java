// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.turpgames.ballgame.utils;

import com.turpgames.framework.v0.util.Color;
import com.turpgames.framework.v0.util.FontManager;
import com.turpgames.framework.v0.util.Game;

public final class R
{
    public static final class colors
    {

        public static final Color buttonDefault;
        public static final Color buttonTouched;
        public static final Color ichiguBlack = Color.fromHex("#000000ff");
        public static final Color ichiguBlue;
        public static final Color ichiguCyan = Color.fromHex("#00f9b0ff");
        public static final Color ichiguGreen = Color.fromHex("#56bd89ff");
        public static final Color ichiguMagenta = Color.fromHex("#f900b0ff");
        public static final Color ichiguRed = Color.fromHex("#d0583bff");
        public static final Color ichiguWhite;
        public static final Color turpYellow = Color.fromHex("#f9b000ff");

        static 
        {
            ichiguWhite = Color.fromHex("#ffffffff");
            ichiguBlue = Color.fromHex("#3974c1ff");
            buttonDefault = ichiguWhite;
            buttonTouched = ichiguBlue;
        }

        public colors()
        {
        }
    }

    public static final class durations
    {

        public static final float blinkDuration = 1F;
        public static final float fadingDuration = 0.25F;
        public static final float toastDisplayDurationBuffer = 1.5F;
        public static final float toastDisplayDurationPerWord = 0.15F;
        public static final float toastSlideDuration = 0.2F;

        public durations()
        {
        }
    }

    public static final class fontSize
    {

        public static final float large;
        public static final float medium;
        public static final float small;
        public static final float xLarge;
        public static final float xSmall;

        static 
        {
            xSmall = 0.5F * FontManager.defaultFontSize;
            small = 0.625F * FontManager.defaultFontSize;
            medium = 0.75F * FontManager.defaultFontSize;
            large = 1.0F * FontManager.defaultFontSize;
            xLarge = 1.25F * FontManager.defaultFontSize;
        }

        public fontSize()
        {
        }
    }

    public static final class game
    {

        public game()
        {
        }
    }

    public static final class game.forms
    {

        public static final String menu = "mainMenu";

        public game.forms()
        {
        }
    }

    public static final class game.screens
    {

        public static final String menu = "menu";

        public game.screens()
        {
        }
    }

    public static final class game.textures
    {

        public static final String facebook = "facebook";
        public static final String fb_default = "fb_default";

        public game.textures()
        {
        }
    }

    public static final class game.textures.toolbar
    {

        public static final String back = "tb_back";
        public static final String musicPlay = "tb_music_play";
        public static final String musicStop = "tb_music_stop";
        public static final String settings = "tb_settings";
        public static final String soundOff = "tb_sound_off";
        public static final String soundOn = "tb_sound_on";
        public static final String vibrationOff = "tb_vibration_off";
        public static final String vibrationOn = "tb_vibration_on";

        public game.textures.toolbar()
        {
        }
    }

    public static final class screens
    {

        public static final String about = "about";
        public static final String game = "game";
        public static final String menu = "menu";
        public static final String result = "result";
        public static final String scoreBoard = "scoreBoard";

        public screens()
        {
        }
    }

    public static final class settings
    {

        public static final String facebookAnnounced = "facebook-announced";
        public static final String music = "music";
        public static final String scoresToSend = "scores-to-send";
        public static final String sound = "sound";
        public static final String vibration = "vibration";

        public settings()
        {
        }
    }

    public static final class settings.hiscores
    {

        public static final String blockSize = "hiscore_blocksize";
        public static final String score = "hiscore_score";

        public settings.hiscores()
        {
        }
    }

    public static final class sizes
    {

        public static final float flagButtonSize = 128F;
        public static final float langFlagButtonSizeToScreen = 0F;
        public static final float libgdxLogoHeight = 33F;
        public static final float libgdxLogoWidth = 200F;
        public static final float maxScale = 0.2F;
        public static final float menuButtonSize = 64F;
        public static final float menuButtonSizeToScreen = 0F;
        public static final float menuButtonSpacing = 0F;
        public static final int scoreImageSize = 64;
        public static final float toolbarMargin = Game.scale(15F);
        public static final float tutorialbuttonSpacing = Game.scale(10F);

        static 
        {
            menuButtonSpacing = Game.scale(15F);
            menuButtonSizeToScreen = Game.scale(64F);
            langFlagButtonSizeToScreen = Game.scale(128F);
        }

        public sizes()
        {
        }
    }

    public static final class strings
    {

        public static final String announceFacebook = "announceFacebook";
        public static final String exitProgramConfirm = "exitProgramConfirm";
        public static final String forceUpgrade = "forceUpgrade";
        public static final String hiScores = "hiScores";
        public static final String hiscoreInfo = "hiscoreInfo";
        public static final String hiscoreResetConfirm = "hiscoreResetConfirm";
        public static final String logoutConfirm = "logoutConfirm";
        public static final String no = "no";
        public static final String ok = "ok";
        public static final String resetHiscore = "resetHiscore";
        public static final String yes = "yes";

        public strings()
        {
        }
    }


    private R()
    {
    }
}
