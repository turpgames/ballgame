// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.turpgames.ballgame.utils;


// Referenced classes of package com.turpgames.ballgame.utils:
//            R

public static final class 
{

    public static final String announceFacebook = "announceFacebook";
    public static final String exitProgramConfirm = "exitProgramConfirm";
    public static final String forceUpgrade = "forceUpgrade";
    public static final String hiScores = "hiScores";
    public static final String hiscoreInfo = "hiscoreInfo";
    public static final String hiscoreResetConfirm = "hiscoreResetConfirm";
    public static final String logoutConfirm = "logoutConfirm";
    public static final String no = "no";
    public static final String ok = "ok";
    public static final String resetHiscore = "resetHiscore";
    public static final String yes = "yes";

    public ()
    {
    }
}
