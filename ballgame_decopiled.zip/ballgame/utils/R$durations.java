// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.turpgames.ballgame.utils;


// Referenced classes of package com.turpgames.ballgame.utils:
//            R

public static final class 
{

    public static final float blinkDuration = 1F;
    public static final float fadingDuration = 0.25F;
    public static final float toastDisplayDurationBuffer = 1.5F;
    public static final float toastDisplayDurationPerWord = 0.15F;
    public static final float toastSlideDuration = 0.2F;

    public ()
    {
    }
}
