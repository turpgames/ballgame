// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.turpgames.ballgame.utils;

import com.turpgames.framework.v0.IResourceManager;
import com.turpgames.framework.v0.ISound;
import com.turpgames.framework.v0.impl.Settings;
import com.turpgames.framework.v0.util.Game;

public class Sounds
{

    public static final ISound gameover = Game.getResourceManager().getSound("gameover");
    public static final ISound ground = Game.getResourceManager().getSound("1");
    public static final ISound hit = Game.getResourceManager().getSound("noscore");
    public static final ISound large = Game.getResourceManager().getSound("8");
    public static final ISound medium = Game.getResourceManager().getSound("16");
    public static final ISound small = Game.getResourceManager().getSound("32");

    public Sounds()
    {
    }

    static 
    {
        Settings.putBoolean("sound", true);
    }
}
