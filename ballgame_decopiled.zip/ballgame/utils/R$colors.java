// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.turpgames.ballgame.utils;

import com.turpgames.framework.v0.util.Color;

// Referenced classes of package com.turpgames.ballgame.utils:
//            R

public static final class 
{

    public static final Color buttonDefault;
    public static final Color buttonTouched;
    public static final Color ichiguBlack = Color.fromHex("#000000ff");
    public static final Color ichiguBlue;
    public static final Color ichiguCyan = Color.fromHex("#00f9b0ff");
    public static final Color ichiguGreen = Color.fromHex("#56bd89ff");
    public static final Color ichiguMagenta = Color.fromHex("#f900b0ff");
    public static final Color ichiguRed = Color.fromHex("#d0583bff");
    public static final Color ichiguWhite;
    public static final Color turpYellow = Color.fromHex("#f9b000ff");

    static 
    {
        ichiguWhite = Color.fromHex("#ffffffff");
        ichiguBlue = Color.fromHex("#3974c1ff");
        buttonDefault = ichiguWhite;
        buttonTouched = ichiguBlue;
    }

    public ()
    {
    }
}
