// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.turpgames.ballgame.utils;

import com.turpgames.framework.v0.util.Debug;
import com.turpgames.framework.v0.util.Game;

// Referenced classes of package com.turpgames.ballgame.utils:
//            ConnectionManager

public class BallGameAds
{

    private static long lastShown = 0L;

    public BallGameAds()
    {
    }

    public static void showAd()
    {
        Debug.println("BallGameAds.showAd");
        if (!ConnectionManager.hasConnection())
        {
            Debug.println("No connection!");
        } else
        {
            long l = System.currentTimeMillis();
            if (l - lastShown > 0x1d4c0L)
            {
                lastShown = l;
                Debug.println("calling Game.showPopUpAd");
                Game.showPopUpAd();
                return;
            }
        }
    }

}
