// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.turpgames.ballgame.utils;

import com.turpgames.framework.v0.util.Game;

// Referenced classes of package com.turpgames.ballgame.utils:
//            R

public static final class 
{

    public static final float flagButtonSize = 128F;
    public static final float langFlagButtonSizeToScreen = 0F;
    public static final float libgdxLogoHeight = 33F;
    public static final float libgdxLogoWidth = 200F;
    public static final float maxScale = 0.2F;
    public static final float menuButtonSize = 64F;
    public static final float menuButtonSizeToScreen = 0F;
    public static final float menuButtonSpacing = 0F;
    public static final int scoreImageSize = 64;
    public static final float toolbarMargin = Game.scale(15F);
    public static final float tutorialbuttonSpacing = Game.scale(10F);

    static 
    {
        menuButtonSpacing = Game.scale(15F);
        menuButtonSizeToScreen = Game.scale(64F);
        langFlagButtonSizeToScreen = Game.scale(128F);
    }

    public ()
    {
    }
}
