// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.turpgames.ballgame.utils;


// Referenced classes of package com.turpgames.ballgame.utils:
//            R

public static final class hiscores
{
    public static final class hiscores
    {

        public static final String blockSize = "hiscore_blocksize";
        public static final String score = "hiscore_score";

        public hiscores()
        {
        }
    }


    public static final String facebookAnnounced = "facebook-announced";
    public static final String music = "music";
    public static final String scoresToSend = "scores-to-send";
    public static final String sound = "sound";
    public static final String vibration = "vibration";

    public hiscores()
    {
    }
}
