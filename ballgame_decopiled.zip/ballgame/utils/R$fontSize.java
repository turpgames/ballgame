// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.turpgames.ballgame.utils;

import com.turpgames.framework.v0.util.FontManager;

// Referenced classes of package com.turpgames.ballgame.utils:
//            R

public static final class ger
{

    public static final float large;
    public static final float medium;
    public static final float small;
    public static final float xLarge;
    public static final float xSmall;

    static 
    {
        xSmall = 0.5F * FontManager.defaultFontSize;
        small = 0.625F * FontManager.defaultFontSize;
        medium = 0.75F * FontManager.defaultFontSize;
        large = 1.0F * FontManager.defaultFontSize;
        xLarge = 1.25F * FontManager.defaultFontSize;
    }

    public ger()
    {
    }
}
