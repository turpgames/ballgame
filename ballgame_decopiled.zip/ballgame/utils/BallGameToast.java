// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.turpgames.ballgame.utils;

import com.turpgames.framework.v0.component.Toast;
import com.turpgames.framework.v0.util.Color;

// Referenced classes of package com.turpgames.ballgame.utils:
//            BallGame

public class BallGameToast
{

    private static final BallGameToast instance = new BallGameToast();
    private final Toast toast = new Toast();

    private BallGameToast()
    {
    }

    private static float calculateDuration(String s)
    {
        return 1.5F + 0.15F * (float)s.split(" ").length;
    }

    private static float calculateFontScale(String s)
    {
        if (s.length() < 20)
        {
            return R.fontSize.large;
        }
        if (s.length() < 40)
        {
            return R.fontSize.large;
        } else
        {
            return R.fontSize.small;
        }
    }

    public static void hide()
    {
        instance.toast.hide();
    }

    public static BallGameToast preapreToast()
    {
        hide();
        reset();
        return instance;
    }

    private static void reset()
    {
        instance.setAlpha(1.0F).setDisplayDuration(3F).setFontScale(R.fontSize.medium).setHideOnTap(true).setMessage("").setListener(null).setPadding(30F, 30F).setSlideDuration(0.2F).setTextColor(R.colors.ichiguWhite).setBackColor(R.colors.ichiguBlue);
    }

    public static void show(String s, float f, Color color)
    {
        show(s, f, color, null);
    }

    public static void show(String s, float f, Color color, com.turpgames.framework.v0.component.Toast.IListener ilistener)
    {
        String s1 = BallGame.getString(s);
        if (f < 0.0F)
        {
            f = calculateFontScale(s1);
        }
        Color color1 = R.colors.ichiguWhite;
        float f1 = calculateDuration(s1);
        show(s1, f, color, color1, true, 1.0F, 30F, 30F, f1, 0.2F, ilistener);
    }

    private static void show(String s, float f, Color color, Color color1, boolean flag, float f1, float f2, float f3, 
            float f4, float f5, com.turpgames.framework.v0.component.Toast.IListener ilistener)
    {
        preapreToast().setAlpha(f1).setDisplayDuration(f4).setFontScale(f).setHideOnTap(flag).setMessage(s).setListener(ilistener).setPadding(f2, f3).setSlideDuration(f5).setTextColor(color1).setBackColor(color).show();
    }

    public static void show(String s, Color color)
    {
        show(s, -1F, color);
    }

    public static void showError(String s)
    {
        show(s, R.colors.ichiguRed);
    }

    public static void showError(String s, float f)
    {
        show(s, f, R.colors.ichiguRed);
    }

    public static void showInfo(String s)
    {
        show(s, R.colors.ichiguGreen);
    }

    public static void showInfo(String s, float f)
    {
        show(s, f, R.colors.ichiguGreen);
    }

    public static void showWarning(String s)
    {
        showWarning(s, ((com.turpgames.framework.v0.component.Toast.IListener) (null)));
    }

    public static void showWarning(String s, float f)
    {
        showWarning(s, f, null);
    }

    public static void showWarning(String s, float f, com.turpgames.framework.v0.component.Toast.IListener ilistener)
    {
        show(s, f, R.colors.ichiguBlue, ilistener);
    }

    public static void showWarning(String s, com.turpgames.framework.v0.component.Toast.IListener ilistener)
    {
        showWarning(s, -1F, ilistener);
    }

    public static void updateMessage(String s)
    {
        instance.toast.setMessage(s);
    }

    public BallGameToast setAlpha(float f)
    {
        toast.setAlpha(f);
        return this;
    }

    public BallGameToast setBackColor(Color color)
    {
        toast.setBackColor(color);
        return this;
    }

    public BallGameToast setDisplayDuration(float f)
    {
        toast.setDisplayDuration(f);
        return this;
    }

    public BallGameToast setFontScale(float f)
    {
        toast.setFontScale(f);
        return this;
    }

    public BallGameToast setHideOnTap(boolean flag)
    {
        toast.setHideOnTap(flag);
        return this;
    }

    public BallGameToast setListener(com.turpgames.framework.v0.component.Toast.IListener ilistener)
    {
        toast.setListener(ilistener);
        return this;
    }

    public BallGameToast setMessage(String s)
    {
        toast.setMessage(s);
        return this;
    }

    public BallGameToast setPadding(float f, float f1)
    {
        toast.setPadX(f);
        toast.setPadY(f1);
        return this;
    }

    public BallGameToast setSlideDuration(float f)
    {
        toast.setSlideDuration(f);
        return this;
    }

    public BallGameToast setTextColor(Color color)
    {
        toast.setTextColor(color);
        return this;
    }

    public void show()
    {
        toast.show();
    }

}
