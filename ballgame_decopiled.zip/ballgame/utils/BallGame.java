// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.turpgames.ballgame.utils;

import com.turpgames.ballgame.components.LoadingAnimation;
import com.turpgames.ballgame.entity.Player;
import com.turpgames.framework.v0.component.UIBlocker;
import com.turpgames.framework.v0.impl.LanguageManager;
import com.turpgames.framework.v0.impl.Settings;
import com.turpgames.framework.v0.util.Game;
import java.util.UUID;

public final class BallGame
{

    private static final String anonymousEmail = "anonymous@turpgam.es";
    private static Player player;

    private BallGame()
    {
    }

    public static void blockUI(String s)
    {
        updateBlockMessage(s);
        UIBlocker.instance.block(LoadingAnimation.instance);
    }

    private static String createAnonymousPlayerName()
    {
        return UUID.randomUUID().toString().substring(0, 8);
    }

    public static Player getPlayer()
    {
        if (player == null)
        {
            player = new Player();
            int i = Settings.getInteger("player-id", 0);
            if (i > 0)
            {
                player.setId(i);
                player.setEmail(Settings.getString("player-email", ""));
                player.setFacebookId(Settings.getString("player-fb-id", ""));
                player.setUsername(Settings.getString("player-username", ""));
            } else
            {
                String s = Settings.getString("anonymous-player-name", "");
                if ("".equals(s))
                {
                    s = createAnonymousPlayerName();
                    Settings.putString("anonymous-player-name", s);
                }
                player.setId(0);
                player.setEmail("anonymous@turpgam.es");
                player.setFacebookId(s);
                player.setUsername((new StringBuilder("Player ")).append(s).toString());
            }
        }
        return player;
    }

    public static String getString(String s)
    {
        return Game.getLanguageManager().getString(s);
    }

    public static boolean isPlayerAnonymous()
    {
        return "anonymous@turpgam.es".equals(getPlayer().getEmail());
    }

    public static boolean isPlayerRegistered()
    {
        return getPlayer().getId() > 0;
    }

    public static void unblockUI()
    {
        UIBlocker.instance.unblock();
    }

    public static void updateBlockMessage(String s)
    {
        LoadingAnimation.instance.setMessage(s);
    }
}
