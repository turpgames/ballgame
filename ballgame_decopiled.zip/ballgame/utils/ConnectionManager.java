// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.turpgames.ballgame.utils;

import java.net.URL;
import java.net.URLConnection;

public class ConnectionManager
{

    private static final long checkInterval = 0x493e0L;
    private static final int connectTimeout = 2000;
    private static boolean hasConnection;
    private static long lastCheck;

    public ConnectionManager()
    {
    }

    private static void checkConnection()
    {
        URLConnection urlconnection = (new URL("http://www.google.com")).openConnection();
        urlconnection.setConnectTimeout(2000);
        urlconnection.connect();
        hasConnection = true;
        lastCheck = System.currentTimeMillis();
        return;
        Throwable throwable;
        throwable;
        hasConnection = false;
        lastCheck = System.currentTimeMillis();
        return;
        Exception exception;
        exception;
        lastCheck = System.currentTimeMillis();
        throw exception;
    }

    public static boolean hasConnection()
    {
        if (System.currentTimeMillis() - lastCheck > 0x493e0L)
        {
            init();
        }
        return hasConnection;
    }

    public static void init()
    {
        com.turpgames.utils.Util.Threading.runInBackground(new Runnable() {

            public void run()
            {
                ConnectionManager.checkConnection();
            }

        });
    }

}
