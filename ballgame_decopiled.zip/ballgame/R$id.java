// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.turpgames.ballgame;


// Referenced classes of package com.turpgames.ballgame:
//            R

public static final class 
{

    public static final int com_facebook_body_frame = 0x7f060019;
    public static final int com_facebook_button_xout = 0x7f06001b;
    public static final int com_facebook_login_activity_progress_bar = 0x7f060009;
    public static final int com_facebook_picker_activity_circle = 0x7f060008;
    public static final int com_facebook_picker_checkbox = 0x7f06000b;
    public static final int com_facebook_picker_checkbox_stub = 0x7f06000f;
    public static final int com_facebook_picker_divider = 0x7f060013;
    public static final int com_facebook_picker_done_button = 0x7f060012;
    public static final int com_facebook_picker_image = 0x7f06000c;
    public static final int com_facebook_picker_list_section_header = 0x7f060010;
    public static final int com_facebook_picker_list_view = 0x7f060007;
    public static final int com_facebook_picker_profile_pic_stub = 0x7f06000d;
    public static final int com_facebook_picker_row_activity_circle = 0x7f06000a;
    public static final int com_facebook_picker_search_text = 0x7f060018;
    public static final int com_facebook_picker_title = 0x7f06000e;
    public static final int com_facebook_picker_title_bar = 0x7f060015;
    public static final int com_facebook_picker_title_bar_stub = 0x7f060014;
    public static final int com_facebook_picker_top_bar = 0x7f060011;
    public static final int com_facebook_search_bar_view = 0x7f060017;
    public static final int com_facebook_tooltip_bubble_view_bottom_pointer = 0x7f06001d;
    public static final int com_facebook_tooltip_bubble_view_text_body = 0x7f06001c;
    public static final int com_facebook_tooltip_bubble_view_top_pointer = 0x7f06001a;
    public static final int com_facebook_usersettingsfragment_login_button = 0x7f060020;
    public static final int com_facebook_usersettingsfragment_logo_image = 0x7f06001e;
    public static final int com_facebook_usersettingsfragment_profile_name = 0x7f06001f;
    public static final int hybrid = 0x7f060004;
    public static final int large = 0x7f060006;
    public static final int none = 0x7f060000;
    public static final int normal = 0x7f060001;
    public static final int picker_subtitle = 0x7f060016;
    public static final int satellite = 0x7f060002;
    public static final int small = 0x7f060005;
    public static final int terrain = 0x7f060003;

    public ()
    {
    }
}
