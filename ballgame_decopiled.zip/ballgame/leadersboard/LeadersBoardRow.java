// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.turpgames.ballgame.leadersboard;

import com.turpgames.ballgame.entity.Player;
import com.turpgames.ballgame.entity.Score;
import com.turpgames.framework.v0.IDrawable;
import com.turpgames.framework.v0.impl.Text;
import com.turpgames.framework.v0.util.Vector;

public class LeadersBoardRow
    implements IDrawable
{

    private final Vector bottomLeft = new Vector(25F, 100F);
    private final Text maxScore;
    private float maxScoreWidth;
    private float nameWidth;
    private final Text playerName;
    private final Text rank;
    private float rankWidth;
    private final float rowHeight = 40F;
    private final float rowWidth = 500F;
    private final Text score;
    private final Vector topRight = new Vector(525F, 525F);

    public LeadersBoardRow(int i, Score score1, Player player)
    {
        rankWidth = 0.05F;
        nameWidth = 0.6F;
        maxScoreWidth = 0.2F;
        rank = createText((new StringBuilder(String.valueOf(i))).append(".").toString());
        playerName = createText(player.getUsername());
        maxScore = createText((new StringBuilder(String.valueOf(score1.getMaxNumber()))).toString());
        score = createText((new StringBuilder(String.valueOf(score1.getScore()))).toString());
        setLocations(Math.min(10, i - 1));
    }

    private static Text createText(String s)
    {
        Text text = new Text();
        text.setText(s);
        text.setAlignment(1, 1);
        text.setFontScale(0.5F);
        return text;
    }

    private void setLocations(int i)
    {
        float f = topRight.y - 40F * (float)i;
        float f1 = bottomLeft.x;
        rank.setLocation(f1, f);
        playerName.setLocation(f1 + 500F * rankWidth, f);
        maxScore.setLocation(f1 + 500F * (rankWidth + nameWidth), f);
        score.setLocation(f1 + 500F * (rankWidth + nameWidth + maxScoreWidth), f);
    }

    public void draw()
    {
        rank.draw();
        playerName.draw();
        maxScore.draw();
        score.draw();
    }
}
