// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.turpgames.ballgame.leadersboard;

import com.turpgames.ballgame.entity.LeadersBoard;
import com.turpgames.framework.v0.ISettings;
import com.turpgames.framework.v0.util.Game;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

// Referenced classes of package com.turpgames.ballgame.leadersboard:
//            LeadersBoardCacheItem

public final class LeadersBoardCache
{

    private static final Map cache = new HashMap();
    private static final String settingsKeyPrefix = "LeadersBoardCache_";
    private static final long timeout = 0x124f80L;

    private LeadersBoardCache()
    {
    }

    public static LeadersBoard getLeadersBoard(int i, int j, int k, boolean flag)
    {
        String s;
        LeadersBoardCacheItem leadersboardcacheitem;
        s = prepareKey(i, j, k);
        leadersboardcacheitem = (LeadersBoardCacheItem)cache.get(s);
        if (leadersboardcacheitem != null) goto _L2; else goto _L1
_L1:
        leadersboardcacheitem = readFromSettings(s);
        if (leadersboardcacheitem != null) goto _L4; else goto _L3
_L3:
        return null;
_L4:
        cache.put(s, leadersboardcacheitem);
_L2:
        Date date = new Date();
        if (flag || date.getTime() - leadersboardcacheitem.getLastLoadDate().getTime() <= 0x124f80L)
        {
            return leadersboardcacheitem.getLeadersBoard();
        }
        if (true) goto _L3; else goto _L5
_L5:
    }

    private static String prepareKey(int i, int j, int k)
    {
        return (new StringBuilder(String.valueOf(i))).append(j).append(k).toString();
    }

    public static void putLeadersBoard(int i, int j, int k, LeadersBoard leadersboard)
    {
        String s = prepareKey(i, j, k);
        LeadersBoardCacheItem leadersboardcacheitem = new LeadersBoardCacheItem();
        leadersboardcacheitem.setLeadersBoard(leadersboard);
        leadersboardcacheitem.setLastLoadDate(new Date());
        cache.put(s, leadersboardcacheitem);
        writeToSettings(s, leadersboardcacheitem);
    }

    private static LeadersBoardCacheItem readFromSettings(String s)
    {
        String s1 = (new StringBuilder("LeadersBoardCache_")).append(s).toString();
        String s2 = Game.getSettings().getString(s1, null);
        if (s2 == null)
        {
            return null;
        } else
        {
            return (LeadersBoardCacheItem)com.turpgames.utils.Util.IO.deserialize(com.turpgames.utils.Util.Strings.fromBase64String(s2));
        }
    }

    private static void writeToSettings(String s, LeadersBoardCacheItem leadersboardcacheitem)
    {
        String s1 = (new StringBuilder("LeadersBoardCache_")).append(s).toString();
        String s2 = com.turpgames.utils.Util.Strings.toBase64String(com.turpgames.utils.Util.IO.serialize(leadersboardcacheitem));
        Game.getSettings().putString(s1, s2);
    }

}
