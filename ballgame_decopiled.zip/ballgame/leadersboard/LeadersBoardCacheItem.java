// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.turpgames.ballgame.leadersboard;

import com.turpgames.ballgame.entity.LeadersBoard;
import java.io.Serializable;
import java.util.Date;

public class LeadersBoardCacheItem
    implements Serializable
{

    private static final long serialVersionUID = 0xb960287c9a154f08L;
    private Date lastLoadDate;
    private LeadersBoard leadersBoard;

    public LeadersBoardCacheItem()
    {
    }

    public Date getLastLoadDate()
    {
        return lastLoadDate;
    }

    public LeadersBoard getLeadersBoard()
    {
        return leadersBoard;
    }

    public void setLastLoadDate(Date date)
    {
        lastLoadDate = date;
    }

    public void setLeadersBoard(LeadersBoard leadersboard)
    {
        leadersBoard = leadersboard;
    }
}
