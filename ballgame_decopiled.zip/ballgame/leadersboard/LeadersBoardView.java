// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.turpgames.ballgame.leadersboard;

import com.turpgames.ballgame.entity.LeadersBoard;
import com.turpgames.ballgame.entity.Score;
import com.turpgames.framework.v0.IView;
import com.turpgames.framework.v0.impl.Text;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

// Referenced classes of package com.turpgames.ballgame.leadersboard:
//            LeadersBoardRow

class LeadersBoardView
    implements IView
{

    private final int days;
    private final String id;
    private final int mode;
    private volatile List rows;
    private final Text subTitle = new Text();
    private final Text title = new Text();

    public LeadersBoardView(int i, int j)
    {
        rows = new ArrayList();
        mode = i;
        days = j;
        title.setAlignment(0, 2);
        title.setPadY(150F);
        subTitle.setAlignment(0, 2);
        subTitle.setPadY(200F);
        subTitle.setFontScale(0.5F);
        if (j == -1)
        {
            subTitle.setText("All Time");
        }
        if (j == 30)
        {
            subTitle.setText("Last Month");
        }
        if (j == 7)
        {
            subTitle.setText("Last Week");
        }
        if (j == 1)
        {
            subTitle.setText("Today");
        }
        id = (new StringBuilder(String.valueOf(title.getText()))).append(subTitle.getText()).toString();
    }

    private void bindData(LeadersBoard leadersboard)
    {
        ArrayList arraylist = new ArrayList();
        Score ascore[] = leadersboard.getScores();
        int i = ascore.length;
        int j = 0;
        int k = 1;
        do
        {
            if (j >= i)
            {
                rows = arraylist;
                return;
            }
            Score score = ascore[j];
            com.turpgames.ballgame.entity.Player player = leadersboard.getPlayer(score.getPlayerId());
            int l = k + 1;
            arraylist.add(new LeadersBoardRow(k, score, player));
            j++;
            k = l;
        } while (true);
    }

    public void activate()
    {
    }

    public boolean deactivate()
    {
        return true;
    }

    public void draw()
    {
        title.draw();
        subTitle.draw();
        Iterator iterator = rows.iterator();
        do
        {
            if (!iterator.hasNext())
            {
                return;
            }
            ((LeadersBoardRow)iterator.next()).draw();
        } while (true);
    }

    public String getId()
    {
        return id;
    }

    public void loadScores()
    {
    }
}
