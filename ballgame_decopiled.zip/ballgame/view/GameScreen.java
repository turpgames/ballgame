// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.turpgames.ballgame.view;

import com.turpgames.ballgame.components.BallGameLogo;
import com.turpgames.ballgame.controller.GameController;
import com.turpgames.framework.v0.client.TurpClient;
import com.turpgames.framework.v0.impl.Screen;
import com.turpgames.framework.v0.util.Game;

// Referenced classes of package com.turpgames.ballgame.view:
//            IScreenView

public class GameScreen extends Screen
    implements IScreenView
{

    private GameController controller;
    private boolean isFirstActivate;

    public GameScreen()
    {
        isFirstActivate = true;
    }

    public void init()
    {
        super.init();
        controller = new GameController(this);
        registerDrawable(new BallGameLogo(), 100);
    }

    protected void onAfterActivate()
    {
        if (isFirstActivate)
        {
            isFirstActivate = false;
            TurpClient.init();
        }
        controller.activate();
    }

    protected boolean onBack()
    {
        Game.exit();
        return false;
    }

    protected boolean onBeforeDeactivate()
    {
        controller.deactivate();
        return super.onBeforeDeactivate();
    }

    public void update()
    {
        super.update();
        controller.update();
    }
}
