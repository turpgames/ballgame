// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.turpgames.ballgame.view;

import com.turpgames.framework.v0.component.IButtonListener;
import com.turpgames.framework.v0.util.Game;

// Referenced classes of package com.turpgames.ballgame.view:
//            AboutScreen

class val.url
    implements IButtonListener
{

    private final String val$url;

    public void onButtonTapped()
    {
        Game.openUrl(val$url);
    }

    onListener()
    {
        val$url = s;
        super();
    }
}
