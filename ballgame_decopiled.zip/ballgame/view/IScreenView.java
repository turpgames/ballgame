// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.turpgames.ballgame.view;

import com.turpgames.framework.v0.IDrawable;
import com.turpgames.framework.v0.IInputListener;

public interface IScreenView
{

    public abstract void registerDrawable(IDrawable idrawable, int i);

    public abstract void registerInputListener(IInputListener iinputlistener);

    public abstract void unregisterDrawable(IDrawable idrawable);

    public abstract void unregisterInputListener(IInputListener iinputlistener);
}
