// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.turpgames.ballgame;


// Referenced classes of package com.turpgames.ballgame:
//            R

public static final class 
{

    public static final int com_facebook_blue = 0x7f05000c;
    public static final int com_facebook_loginview_text_color = 0x7f050010;
    public static final int com_facebook_picker_search_bar_background = 0x7f05000a;
    public static final int com_facebook_picker_search_bar_text = 0x7f05000b;
    public static final int com_facebook_usersettingsfragment_connected_shadow_color = 0x7f05000e;
    public static final int com_facebook_usersettingsfragment_connected_text_color = 0x7f05000d;
    public static final int com_facebook_usersettingsfragment_not_connected_text_color = 0x7f05000f;
    public static final int common_action_bar_splitter = 0x7f050009;
    public static final int common_signin_btn_dark_text_default = 0x7f050000;
    public static final int common_signin_btn_dark_text_disabled = 0x7f050002;
    public static final int common_signin_btn_dark_text_focused = 0x7f050003;
    public static final int common_signin_btn_dark_text_pressed = 0x7f050001;
    public static final int common_signin_btn_default_background = 0x7f050008;
    public static final int common_signin_btn_light_text_default = 0x7f050004;
    public static final int common_signin_btn_light_text_disabled = 0x7f050006;
    public static final int common_signin_btn_light_text_focused = 0x7f050007;
    public static final int common_signin_btn_light_text_pressed = 0x7f050005;
    public static final int common_signin_btn_text_dark = 0x7f050011;
    public static final int common_signin_btn_text_light = 0x7f050012;

    public ()
    {
    }
}
