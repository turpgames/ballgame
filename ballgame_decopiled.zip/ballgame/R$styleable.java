// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.turpgames.ballgame;


// Referenced classes of package com.turpgames.ballgame:
//            R

public static final class 
{

    public static final int AdsAttrs[] = {
        0x7f010000, 0x7f010001, 0x7f010002
    };
    public static final int AdsAttrs_adSize = 0;
    public static final int AdsAttrs_adSizes = 1;
    public static final int AdsAttrs_adUnitId = 2;
    public static final int MapAttrs[] = {
        0x7f010003, 0x7f010004, 0x7f010005, 0x7f010006, 0x7f010007, 0x7f010008, 0x7f010009, 0x7f01000a, 0x7f01000b, 0x7f01000c, 
        0x7f01000d, 0x7f01000e, 0x7f01000f, 0x7f010010
    };
    public static final int MapAttrs_cameraBearing = 1;
    public static final int MapAttrs_cameraTargetLat = 2;
    public static final int MapAttrs_cameraTargetLng = 3;
    public static final int MapAttrs_cameraTilt = 4;
    public static final int MapAttrs_cameraZoom = 5;
    public static final int MapAttrs_mapType = 0;
    public static final int MapAttrs_uiCompass = 6;
    public static final int MapAttrs_uiRotateGestures = 7;
    public static final int MapAttrs_uiScrollGestures = 8;
    public static final int MapAttrs_uiTiltGestures = 9;
    public static final int MapAttrs_uiZoomControls = 10;
    public static final int MapAttrs_uiZoomGestures = 11;
    public static final int MapAttrs_useViewLifecycle = 12;
    public static final int MapAttrs_zOrderOnTop = 13;
    public static final int com_facebook_friend_picker_fragment[] = {
        0x7f010018
    };
    public static final int com_facebook_friend_picker_fragment_multi_select = 0;
    public static final int com_facebook_login_view[] = {
        0x7f01001d, 0x7f01001e, 0x7f01001f, 0x7f010020
    };
    public static final int com_facebook_login_view_confirm_logout = 0;
    public static final int com_facebook_login_view_fetch_user_info = 1;
    public static final int com_facebook_login_view_login_text = 2;
    public static final int com_facebook_login_view_logout_text = 3;
    public static final int com_facebook_picker_fragment[] = {
        0x7f010011, 0x7f010012, 0x7f010013, 0x7f010014, 0x7f010015, 0x7f010016, 0x7f010017
    };
    public static final int com_facebook_picker_fragment_done_button_background = 6;
    public static final int com_facebook_picker_fragment_done_button_text = 4;
    public static final int com_facebook_picker_fragment_extra_fields = 1;
    public static final int com_facebook_picker_fragment_show_pictures = 0;
    public static final int com_facebook_picker_fragment_show_title_bar = 2;
    public static final int com_facebook_picker_fragment_title_bar_background = 5;
    public static final int com_facebook_picker_fragment_title_text = 3;
    public static final int com_facebook_place_picker_fragment[] = {
        0x7f010019, 0x7f01001a, 0x7f01001b, 0x7f01001c
    };
    public static final int com_facebook_place_picker_fragment_radius_in_meters = 0;
    public static final int com_facebook_place_picker_fragment_results_limit = 1;
    public static final int com_facebook_place_picker_fragment_search_text = 2;
    public static final int com_facebook_place_picker_fragment_show_search_box = 3;
    public static final int com_facebook_profile_picture_view[] = {
        0x7f010021, 0x7f010022
    };
    public static final int com_facebook_profile_picture_view_is_cropped = 1;
    public static final int com_facebook_profile_picture_view_preset_size;


    public ()
    {
    }
}
