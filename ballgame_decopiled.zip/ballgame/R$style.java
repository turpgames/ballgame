// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.turpgames.ballgame;


// Referenced classes of package com.turpgames.ballgame:
//            R

public static final class 
{

    public static final int AppBaseTheme = 0x7f080000;
    public static final int AppTheme = 0x7f080001;
    public static final int GdxTheme = 0x7f080005;
    public static final int com_facebook_loginview_default_style = 0x7f080002;
    public static final int com_facebook_loginview_silver_style = 0x7f080003;
    public static final int tooltip_bubble_text = 0x7f080004;

    public ()
    {
    }
}
