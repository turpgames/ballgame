// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.turpgames.ballgame;

import com.badlogic.gdx.backends.android.AndroidApplicationConfiguration;
import com.turpgames.framework.v0.android.AndroidGameActivity;

public class MainActivity extends AndroidGameActivity
{

    public MainActivity()
    {
    }

    protected AndroidApplicationConfiguration getAndroidApplicationConfiguration()
    {
        AndroidApplicationConfiguration androidapplicationconfiguration = new AndroidApplicationConfiguration();
        androidapplicationconfiguration.useAccelerometer = false;
        androidapplicationconfiguration.useCompass = false;
        return androidapplicationconfiguration;
    }
}
