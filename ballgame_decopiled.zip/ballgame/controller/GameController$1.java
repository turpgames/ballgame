// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.turpgames.ballgame.controller;

import com.turpgames.framework.v0.impl.InputListener;

// Referenced classes of package com.turpgames.ballgame.controller:
//            GameController

class > extends InputListener
{

    final GameController this$0;

    public boolean tap(float f, float f1, int i, int j)
    {
        return GameController.access$1(GameController.this);
    }

    public boolean touchDown(float f, float f1, int i, int j)
    {
        return GameController.access$0(GameController.this, f, f1);
    }

    ()
    {
        this$0 = GameController.this;
        super();
    }
}
