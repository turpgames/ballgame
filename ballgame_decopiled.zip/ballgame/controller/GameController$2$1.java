// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.turpgames.ballgame.controller;

import com.turpgames.framework.v0.client.IShareMessageBuilder;
import com.turpgames.framework.v0.client.TurpClient;
import java.io.PrintStream;

// Referenced classes of package com.turpgames.ballgame.controller:
//            GameController

class this._cls1
    implements IShareMessageBuilder
{

    final is._cls0 this$1;

    public String buildMessage()
    {
        return (new StringBuilder("I just made ")).append(GameController.access$2(_fld0)).append(" hops in Ball Game!").toString();
    }

    is._cls0()
    {
        this$1 = this._cls1.this;
        super();
    }

    // Unreferenced inner class com/turpgames/ballgame/controller/GameController$2

/* anonymous class */
    class GameController._cls2
        implements com.turpgames.ballgame.components.ResultView.IListener
    {

        final GameController this$0;

        public void onRestartGame()
        {
            GameController.access$3(GameController.this);
        }

        public void onShareScore()
        {
            TurpClient.shareScoreOnFacebook(new GameController._cls2._cls1());
        }

        public void onShowLeadersBoard()
        {
            System.out.println("Leaders Board");
        }


            
            {
                this$0 = GameController.this;
                super();
            }
    }

}
