// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.turpgames.ballgame.controller;

import com.turpgames.ballgame.components.HelpView;
import com.turpgames.ballgame.components.ResultView;
import com.turpgames.ballgame.objects.Ball;
import com.turpgames.ballgame.objects.Walls;
import com.turpgames.ballgame.utils.BallGameAds;
import com.turpgames.ballgame.utils.Sounds;
import com.turpgames.ballgame.view.IScreenView;
import com.turpgames.framework.v0.ISound;
import com.turpgames.framework.v0.client.IShareMessageBuilder;
import com.turpgames.framework.v0.client.TurpClient;
import com.turpgames.framework.v0.impl.InputListener;
import com.turpgames.framework.v0.impl.Settings;
import com.turpgames.framework.v0.impl.Text;
import com.turpgames.framework.v0.util.Game;
import com.turpgames.framework.v0.util.Rectangle;
import com.turpgames.framework.v0.util.Vector;
import java.io.PrintStream;

public class GameController
{

    private final Ball ball = new Ball();
    private boolean gameOver;
    private final HelpView help = new HelpView();
    private int hiscore;
    private final Text hiscoreText = new Text();
    private final Text infoText = new Text();
    private boolean isPlaying;
    private final InputListener listener = new InputListener() {

        final GameController this$0;

        public boolean tap(float f, float f1, int i, int j)
        {
            return onTap();
        }

        public boolean touchDown(float f, float f1, int i, int j)
        {
            return onTouchDown(f, f1);
        }

            
            {
                this$0 = GameController.this;
                super();
            }
    };
    private final ResultView resultView = new ResultView(new com.turpgames.ballgame.components.ResultView.IListener() {

        final GameController this$0;

        public void onRestartGame()
        {
            restartGame();
        }

        public void onShareScore()
        {
            TurpClient.shareScoreOnFacebook(new IShareMessageBuilder() {

                final _cls2 this$1;

                public String buildMessage()
                {
                    return (new StringBuilder("I just made ")).append(score).append(" hops in Ball Game!").toString();
                }

            
            {
                this$1 = _cls2.this;
                super();
            }
            });
        }

        public void onShowLeadersBoard()
        {
            System.out.println("Leaders Board");
        }


            
            {
                this$0 = GameController.this;
                super();
            }
    });
    private int score;
    private final Text scoreText = new Text();
    private final IScreenView view;
    private final Walls walls = new Walls();

    public GameController(IScreenView iscreenview)
    {
        isPlaying = false;
        gameOver = false;
        view = iscreenview;
        scoreText.setFontScale(0.66F);
        scoreText.setAlignment(1, 2);
        scoreText.setPadding(Game.scale(10F), Game.scale(10F));
        hiscoreText.setFontScale(0.66F);
        hiscoreText.setAlignment(2, 2);
        hiscoreText.setPadding(Game.scale(10F), Game.scale(10F));
        infoText.setAlignment(0, 0);
        infoText.setText("Touch To Begin");
    }

    private void beginPlaying()
    {
        isPlaying = true;
        ball.beginMove();
        score = 0;
        scoreText.setText((new StringBuilder(String.valueOf(score))).toString());
        view.unregisterDrawable(infoText);
        view.unregisterDrawable(help);
    }

    private void endGame()
    {
        isPlaying = false;
        gameOver = true;
        ball.stopMoving();
        resultView.activate();
        view.unregisterInputListener(listener);
        view.registerDrawable(resultView, 300);
        Sounds.gameover.play();
    }

    private boolean hasCollision()
    {
        float f = ball.getLocation().x;
        float f1 = ball.getLocation().y;
        float f2 = ball.getSize();
        Rectangle rectangle = walls.getRect();
        if (f < rectangle.x)
        {
            ball.getLocation().x = rectangle.x;
            return true;
        }
        if (f1 < rectangle.y)
        {
            ball.getLocation().y = rectangle.y;
            return true;
        }
        if (rectangle.x + rectangle.width < f + f2)
        {
            ball.getLocation().x = (rectangle.x + rectangle.width) - f2;
            return true;
        }
        if (rectangle.y + rectangle.height < f1 + f2)
        {
            ball.getLocation().y = (rectangle.y + rectangle.height) - f2;
            return true;
        } else
        {
            return false;
        }
    }

    private boolean onTap()
    {
        if (gameOver)
        {
            restartGame();
            return true;
        } else
        {
            return false;
        }
    }

    private boolean onTouchDown(float f, float f1)
    {
        if (gameOver)
        {
            return false;
        }
        if (!isPlaying)
        {
            beginPlaying();
        } else
        {
            score = 1 + score;
            scoreText.setText((new StringBuilder(String.valueOf(score))).toString());
            if (score > hiscore)
            {
                hiscore = score;
                Settings.putInteger("hi-score", hiscore);
                hiscoreText.setText((new StringBuilder("Hi: ")).append(hiscore).toString());
            }
            ball.hit(Game.screenToViewportX(f));
            Sounds.hit.play();
        }
        return true;
    }

    private void restartGame()
    {
        view.registerDrawable(help, 200);
        BallGameAds.showAd();
        gameOver = false;
        isPlaying = false;
        ball.reset();
        score = 0;
        scoreText.setText((new StringBuilder(String.valueOf(score))).toString());
        hiscore = Settings.getInteger("hi-score", 0);
        hiscoreText.setText((new StringBuilder("Hi: ")).append(hiscore).toString());
        resultView.deactivate();
        view.unregisterDrawable(resultView);
        view.registerDrawable(infoText, 200);
        view.registerInputListener(listener);
    }

    public void activate()
    {
        view.registerDrawable(walls, 200);
        view.registerDrawable(ball, 200);
        view.registerDrawable(scoreText, 300);
        view.registerDrawable(hiscoreText, 300);
        restartGame();
    }

    public void deactivate()
    {
        view.unregisterInputListener(listener);
        view.unregisterDrawable(ball);
        view.unregisterDrawable(walls);
        view.unregisterDrawable(scoreText);
        view.unregisterDrawable(hiscoreText);
        view.unregisterDrawable(resultView);
        resultView.deactivate();
    }

    public void update()
    {
        if (isPlaying && hasCollision())
        {
            ball.update();
            endGame();
        }
    }




}
