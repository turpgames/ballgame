// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.turpgames.ballgame.components;

import com.turpgames.ballgame.utils.Textures;
import com.turpgames.framework.v0.IDrawable;
import com.turpgames.framework.v0.ITexture;
import com.turpgames.framework.v0.impl.GameObject;
import com.turpgames.framework.v0.util.Game;
import com.turpgames.framework.v0.util.TextureDrawer;
import com.turpgames.framework.v0.util.Vector;

public class HelpView
    implements IDrawable
{
    class HelpItem extends GameObject
    {

        private final ITexture texture;
        final HelpView this$0;

        public void draw()
        {
            TextureDrawer.draw(texture, this);
        }

        public void setLocation(float f, float f1)
        {
            getLocation().set(f, f1);
        }

        HelpItem(ITexture itexture)
        {
            this$0 = HelpView.this;
            super();
            texture = itexture;
            setWidth(150F);
            setHeight(150F);
        }
    }


    private static final float itemSize = 150F;
    private final HelpItem tapBottom;
    private final HelpItem tapLeft;
    private final HelpItem tapRight;

    public HelpView()
    {
        tapRight = new HelpItem(Textures.tap_right);
        tapBottom = new HelpItem(Textures.tap_bottom);
        tapLeft = new HelpItem(Textures.tap_left);
        float f = (Game.getVirtualWidth() - 450F) / 4F;
        tapRight.setLocation(f, 150F);
        tapBottom.setLocation(150F + 2.0F * f, 150F);
        tapLeft.setLocation(300F + 3F * f, 150F);
    }

    public void draw()
    {
        tapRight.draw();
        tapBottom.draw();
        tapLeft.draw();
    }
}
