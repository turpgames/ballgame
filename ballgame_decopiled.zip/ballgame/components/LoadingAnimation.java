// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.turpgames.ballgame.components;

import com.turpgames.framework.v0.impl.AnimatedGameObject;
import com.turpgames.framework.v0.impl.Text;
import com.turpgames.framework.v0.util.Game;
import com.turpgames.framework.v0.util.Vector;

public class LoadingAnimation extends AnimatedGameObject
{

    public static final LoadingAnimation instance = new LoadingAnimation();
    private final Text message = new Text();

    private LoadingAnimation()
    {
        addAnimation("loading");
        setWidth(75F);
        setHeight(75F);
        getLocation().x = (Game.getVirtualWidth() - getWidth()) / 2.0F;
        getLocation().y = (Game.getVirtualHeight() - getHeight()) / 2.0F;
        startAnimation("loading");
        message.setFontScale(0.75F);
        message.setAlignment(0, 1);
        message.setY(getLocation().y - 30F);
    }

    public void draw()
    {
        message.draw();
        super.draw();
    }

    public void setMessage(String s)
    {
        message.setText(s);
    }

}
