// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.turpgames.ballgame.components;


// Referenced classes of package com.turpgames.ballgame.components:
//            ResultView

public static interface 
{

    public abstract void onRestartGame();

    public abstract void onShareScore();

    public abstract void onShowLeadersBoard();
}
