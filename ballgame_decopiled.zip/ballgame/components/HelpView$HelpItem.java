// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.turpgames.ballgame.components;

import com.turpgames.framework.v0.ITexture;
import com.turpgames.framework.v0.impl.GameObject;
import com.turpgames.framework.v0.util.TextureDrawer;
import com.turpgames.framework.v0.util.Vector;

// Referenced classes of package com.turpgames.ballgame.components:
//            HelpView

class setHeight extends GameObject
{

    private final ITexture texture;
    final HelpView this$0;

    public void draw()
    {
        TextureDrawer.draw(texture, this);
    }

    public void setLocation(float f, float f1)
    {
        getLocation().set(f, f1);
    }

    _cls9(ITexture itexture)
    {
        this$0 = HelpView.this;
        super();
        texture = itexture;
        setWidth(150F);
        setHeight(150F);
    }
}
