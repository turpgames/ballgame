// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.turpgames.ballgame.components;

import com.turpgames.framework.v0.component.IButtonListener;

// Referenced classes of package com.turpgames.ballgame.components:
//            ResultView

class istener
    implements IButtonListener
{

    final ResultView this$0;
    private final istener val$listener;

    public void onButtonTapped()
    {
        val$listener.onShareScore();
    }

    istener()
    {
        this$0 = final_resultview;
        val$listener = istener.this;
        super();
    }
}
