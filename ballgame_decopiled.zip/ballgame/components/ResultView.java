// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.turpgames.ballgame.components;

import com.turpgames.framework.v0.IDrawable;
import com.turpgames.framework.v0.component.IButtonListener;
import com.turpgames.framework.v0.component.TextButton;
import com.turpgames.framework.v0.util.Color;
import com.turpgames.framework.v0.util.Game;
import com.turpgames.framework.v0.util.Vector;

public class ResultView
    implements IDrawable
{
    public static interface IListener
    {

        public abstract void onRestartGame();

        public abstract void onShareScore();

        public abstract void onShowLeadersBoard();
    }


    private final TextButton leadersBoardButton;
    private final TextButton restartButton;
    private final TextButton shareScoreButton;

    public ResultView(final IListener listener)
    {
        float f = Game.getVirtualHeight() / 2.0F;
        shareScoreButton = createButton("Share Score", f, new IButtonListener() {

            final ResultView this$0;
            private final IListener val$listener;

            public void onButtonTapped()
            {
                listener.onShareScore();
            }

            
            {
                this$0 = ResultView.this;
                listener = ilistener;
                super();
            }
        });
        restartButton = createButton("Play Again", f - 120F, new IButtonListener() {

            final ResultView this$0;
            private final IListener val$listener;

            public void onButtonTapped()
            {
                listener.onRestartGame();
            }

            
            {
                this$0 = ResultView.this;
                listener = ilistener;
                super();
            }
        });
        leadersBoardButton = createButton("Leaders Board", f + 120F, new IButtonListener() {

            final ResultView this$0;
            private final IListener val$listener;

            public void onButtonTapped()
            {
                listener.onShowLeadersBoard();
            }

            
            {
                this$0 = ResultView.this;
                listener = ilistener;
                super();
            }
        });
    }

    private static TextButton createButton(String s, float f, IButtonListener ibuttonlistener)
    {
        TextButton textbutton = new TextButton(Color.white(), Color.white());
        textbutton.setListener(ibuttonlistener);
        textbutton.setText(s);
        textbutton.getLocation().set((Game.getVirtualWidth() - textbutton.getWidth()) / 2.0F, f);
        textbutton.deactivate();
        return textbutton;
    }

    public void activate()
    {
        restartButton.activate();
        shareScoreButton.activate();
        leadersBoardButton.activate();
    }

    public void deactivate()
    {
        restartButton.deactivate();
        shareScoreButton.deactivate();
        leadersBoardButton.deactivate();
    }

    public void draw()
    {
        restartButton.draw();
        shareScoreButton.draw();
        leadersBoardButton.draw();
    }
}
