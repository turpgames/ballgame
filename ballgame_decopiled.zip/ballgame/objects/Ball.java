// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.turpgames.ballgame.objects;

import com.turpgames.ballgame.utils.Textures;
import com.turpgames.framework.v0.IDrawable;
import com.turpgames.framework.v0.effects.rolling.IRollingEffectSubject;
import com.turpgames.framework.v0.effects.rolling.RollingEffect;
import com.turpgames.framework.v0.impl.DefaultMover;
import com.turpgames.framework.v0.impl.GameObject;
import com.turpgames.framework.v0.util.Game;
import com.turpgames.framework.v0.util.Rotation;
import com.turpgames.framework.v0.util.TextureDrawer;
import com.turpgames.framework.v0.util.Vector;

public class Ball
    implements IDrawable
{
    private static class BallObject extends GameObject
    {

        public void draw()
        {
            TextureDrawer.draw(Textures.ball_blue, this);
        }

        private BallObject()
        {
        }

        BallObject(BallObject ballobject)
        {
            this();
        }
    }


    private static final float gravity = -1000F;
    private static final float hitX = 500F;
    private static final float hitY = 750F;
    private static final float physicsFactor = 100F;
    private final BallObject ball = new BallObject(null);
    private final float radius = 40F;
    private final RollingEffect rollingEffect = new RollingEffect(new IRollingEffectSubject() {

        final Ball this$0;

        public void setRotation(float f)
        {
            ball.getRotation().setRotationZ(f);
            update();
        }

            
            {
                this$0 = Ball.this;
                super();
            }
    });

    public Ball()
    {
        ball.setWidth(80F);
        ball.setHeight(80F);
        ball.getAcceleration().set(0.0F, -1000F);
        reset();
    }

    public void beginMove()
    {
        ball.beginMove(new DefaultMover());
        rollingEffect.start();
    }

    public void draw()
    {
        ball.draw();
    }

    public Vector getLocation()
    {
        return ball.getLocation();
    }

    public float getSize()
    {
        return ball.getWidth();
    }

    public void hit(float f)
    {
        float f1 = ((40F + ball.getLocation().x) - f) / 40F;
        if (Math.abs(f1) >= 0.5F)
        {
            if (f1 > 0.0F)
            {
                f1 = 0.5F;
            } else
            {
                f1 = -0.5F;
            }
        }
        ball.getVelocity().set(500F * f1, 750F);
        rollingEffect.setAngularVelocity(-360F * f1);
    }

    public void reset()
    {
        ball.getVelocity().set(0.0F, 0.0F);
        ball.getLocation().set((Game.getVirtualWidth() - ball.getWidth()) / 2.0F, 0.66F * (Game.getVirtualHeight() - ball.getHeight()));
        rollingEffect.setAngularVelocity(0.0F);
        ball.getRotation().setRotationZ(0.0F);
    }

    public void stopMoving()
    {
        ball.stopMoving();
        rollingEffect.stop();
    }

    public void update()
    {
        ball.getRotation().setOrigin(40F + ball.getLocation().x, 40F + ball.getLocation().y);
    }

}
