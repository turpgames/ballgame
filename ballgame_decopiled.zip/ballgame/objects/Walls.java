// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.turpgames.ballgame.objects;

import com.turpgames.ballgame.utils.Textures;
import com.turpgames.framework.v0.IDrawable;
import com.turpgames.framework.v0.impl.GameObject;
import com.turpgames.framework.v0.util.Color;
import com.turpgames.framework.v0.util.Game;
import com.turpgames.framework.v0.util.Rectangle;
import com.turpgames.framework.v0.util.ShapeDrawer;
import com.turpgames.framework.v0.util.TextureDrawer;
import com.turpgames.framework.v0.util.Vector;

public class Walls
    implements IDrawable
{
    private static class WallsObject extends GameObject
    {

        public void draw()
        {
            TextureDrawer.draw(Textures.bg, this);
            ShapeDrawer.drawRect(this, false);
        }

        private WallsObject()
        {
        }

        WallsObject(WallsObject wallsobject)
        {
            this();
        }
    }


    private static final float h = 0F;
    private static final Rectangle rect = new Rectangle(5F, 5F, w, h);
    private static final float w = 0F;
    private static final Color wallColor = Color.white();
    private static final float x = 5F;
    private static final float y = 5F;
    private WallsObject walls;

    public Walls()
    {
        walls = new WallsObject(null);
        walls.getLocation().set(5F, 5F);
        walls.setWidth(w);
        walls.setHeight(h);
        walls.getColor().set(wallColor);
    }

    public void draw()
    {
        walls.draw();
    }

    public Rectangle getRect()
    {
        return rect;
    }

    static 
    {
        w = Game.getVirtualWidth() - 10F;
        h = Game.getVirtualHeight() - 10F;
    }
}
