// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.turpgames.ballgame.objects;

import com.turpgames.ballgame.utils.Textures;
import com.turpgames.framework.v0.impl.GameObject;
import com.turpgames.framework.v0.util.ShapeDrawer;
import com.turpgames.framework.v0.util.TextureDrawer;

// Referenced classes of package com.turpgames.ballgame.objects:
//            Walls

private static class <init> extends GameObject
{

    public void draw()
    {
        TextureDrawer.draw(Textures.bg, this);
        ShapeDrawer.drawRect(this, false);
    }

    private ()
    {
    }

    ( )
    {
        this();
    }
}
