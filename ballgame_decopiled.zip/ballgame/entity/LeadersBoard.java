// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.turpgames.ballgame.entity;

import java.io.Serializable;

// Referenced classes of package com.turpgames.ballgame.entity:
//            Player, Score

public class LeadersBoard
    implements Serializable
{

    private static final long serialVersionUID = 0xc5280e6117525361L;
    private int days;
    private int ownRank;
    private Score ownScore;
    private int playerId;
    private Player players[];
    private int scoreMode;
    private Score scores[];

    public LeadersBoard()
    {
    }

    public int getDays()
    {
        return days;
    }

    public int getOwnRank()
    {
        return ownRank;
    }

    public Score getOwnScore()
    {
        return ownScore;
    }

    public Player getPlayer(int i)
    {
        Player aplayer[];
        int j;
        int k;
        aplayer = players;
        j = aplayer.length;
        k = 0;
_L6:
        if (k < j) goto _L2; else goto _L1
_L1:
        Player player = null;
_L4:
        return player;
_L2:
        player = aplayer[k];
        if (player.getId() == i) goto _L4; else goto _L3
_L3:
        k++;
        if (true) goto _L6; else goto _L5
_L5:
    }

    public int getPlayerId()
    {
        return playerId;
    }

    public Player[] getPlayers()
    {
        return players;
    }

    public int getScoreMode()
    {
        return scoreMode;
    }

    public Score[] getScores()
    {
        return scores;
    }

    public void setDays(int i)
    {
        days = i;
    }

    public void setOwnRank(int i)
    {
        ownRank = i;
    }

    public void setOwnScore(Score score)
    {
        ownScore = score;
    }

    public void setPlayerId(int i)
    {
        playerId = i;
    }

    public void setPlayers(Player aplayer[])
    {
        players = aplayer;
    }

    public void setScoreMode(int i)
    {
        scoreMode = i;
    }

    public void setScores(Score ascore[])
    {
        scores = ascore;
    }
}
