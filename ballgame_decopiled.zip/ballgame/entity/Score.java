// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.turpgames.ballgame.entity;

import java.io.Serializable;
import java.util.Date;

public class Score
    implements Serializable
{

    public static final int AllTime = -1;
    public static final int Daily = 1;
    public static final int FriendsScores = 2;
    public static final int General = 3;
    public static final int Monthly = 30;
    public static final int MyScores = 1;
    public static final int Weekly = 7;
    private static final long serialVersionUID = 0x35b203afea451f03L;
    private Date date;
    private int maxNumber;
    private int mode;
    private int playerId;
    private int score;
    private long time;

    public Score()
    {
    }

    public Date getDate()
    {
        if (date == null)
        {
            date = new Date(time);
        }
        return date;
    }

    public int getMaxNumber()
    {
        return maxNumber;
    }

    public int getMode()
    {
        return mode;
    }

    public int getPlayerId()
    {
        return playerId;
    }

    public int getScore()
    {
        return score;
    }

    public long getTime()
    {
        return time;
    }

    public void setMaxNumber(int i)
    {
        maxNumber = i;
    }

    public void setMode(int i)
    {
        mode = i;
    }

    public void setPlayerId(int i)
    {
        playerId = i;
    }

    public void setScore(int i)
    {
        score = i;
    }

    public void setTime(long l)
    {
        time = l;
    }
}
