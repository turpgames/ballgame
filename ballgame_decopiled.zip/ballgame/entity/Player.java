// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.turpgames.ballgame.entity;

import java.io.Serializable;

public class Player
    implements Serializable
{

    private static final long serialVersionUID = 0x64173f034c4f4444L;
    private String email;
    private String facebookId;
    private int id;
    private String password;
    private String profilePictureUrl;
    private String username;

    public Player()
    {
    }

    public String getEmail()
    {
        return email;
    }

    public String getFacebookId()
    {
        return facebookId;
    }

    public String getFacebookProfilePictureUrl()
    {
        if (profilePictureUrl == null)
        {
            profilePictureUrl = (new StringBuilder("http://graph.facebook.com/")).append(facebookId).append("/picture?width=64&height=64").toString();
        }
        return profilePictureUrl;
    }

    public int getId()
    {
        return id;
    }

    public String getPassword()
    {
        return password;
    }

    public String getUsername()
    {
        return username;
    }

    public void setEmail(String s)
    {
        email = s;
    }

    public void setFacebookId(String s)
    {
        facebookId = s;
    }

    public void setId(int i)
    {
        id = i;
    }

    public void setPassword(String s)
    {
        password = s;
    }

    public void setUsername(String s)
    {
        username = s;
    }

    public String toString()
    {
        return username;
    }
}
