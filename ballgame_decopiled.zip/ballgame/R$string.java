// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.turpgames.ballgame;


// Referenced classes of package com.turpgames.ballgame:
//            R

public static final class 
{

    public static final int app_id = 0x7f040036;
    public static final int app_name = 0x7f040000;
    public static final int auth_client_needs_enabling_title = 0x7f040016;
    public static final int auth_client_needs_installation_title = 0x7f040017;
    public static final int auth_client_needs_update_title = 0x7f040018;
    public static final int auth_client_play_services_err_notification_msg = 0x7f040019;
    public static final int auth_client_requested_by_msg = 0x7f04001a;
    public static final int auth_client_using_bad_version_title = 0x7f040015;
    public static final int com_facebook_choose_friends = 0x7f04002b;
    public static final int com_facebook_dialogloginactivity_ok_button = 0x7f04001c;
    public static final int com_facebook_internet_permission_error_message = 0x7f04002f;
    public static final int com_facebook_internet_permission_error_title = 0x7f04002e;
    public static final int com_facebook_loading = 0x7f04002d;
    public static final int com_facebook_loginview_cancel_action = 0x7f040022;
    public static final int com_facebook_loginview_log_in_button = 0x7f04001e;
    public static final int com_facebook_loginview_log_out_action = 0x7f040021;
    public static final int com_facebook_loginview_log_out_button = 0x7f04001d;
    public static final int com_facebook_loginview_logged_in_as = 0x7f04001f;
    public static final int com_facebook_loginview_logged_in_using_facebook = 0x7f040020;
    public static final int com_facebook_logo_content_description = 0x7f040023;
    public static final int com_facebook_nearby = 0x7f04002c;
    public static final int com_facebook_picker_done_button_text = 0x7f04002a;
    public static final int com_facebook_placepicker_subtitle_catetory_only_format = 0x7f040028;
    public static final int com_facebook_placepicker_subtitle_format = 0x7f040027;
    public static final int com_facebook_placepicker_subtitle_were_here_only_format = 0x7f040029;
    public static final int com_facebook_requesterror_password_changed = 0x7f040032;
    public static final int com_facebook_requesterror_permissions = 0x7f040034;
    public static final int com_facebook_requesterror_reconnect = 0x7f040033;
    public static final int com_facebook_requesterror_relogin = 0x7f040031;
    public static final int com_facebook_requesterror_web_login = 0x7f040030;
    public static final int com_facebook_tooltip_default = 0x7f040035;
    public static final int com_facebook_usersettingsfragment_log_in_button = 0x7f040024;
    public static final int com_facebook_usersettingsfragment_logged_in = 0x7f040025;
    public static final int com_facebook_usersettingsfragment_not_logged_in = 0x7f040026;
    public static final int common_google_play_services_enable_button = 0x7f040007;
    public static final int common_google_play_services_enable_text = 0x7f040006;
    public static final int common_google_play_services_enable_title = 0x7f040005;
    public static final int common_google_play_services_install_button = 0x7f040004;
    public static final int common_google_play_services_install_text_phone = 0x7f040002;
    public static final int common_google_play_services_install_text_tablet = 0x7f040003;
    public static final int common_google_play_services_install_title = 0x7f040001;
    public static final int common_google_play_services_invalid_account_text = 0x7f04000d;
    public static final int common_google_play_services_invalid_account_title = 0x7f04000c;
    public static final int common_google_play_services_network_error_text = 0x7f04000b;
    public static final int common_google_play_services_network_error_title = 0x7f04000a;
    public static final int common_google_play_services_unknown_issue = 0x7f04000e;
    public static final int common_google_play_services_unsupported_date_text = 0x7f040011;
    public static final int common_google_play_services_unsupported_text = 0x7f040010;
    public static final int common_google_play_services_unsupported_title = 0x7f04000f;
    public static final int common_google_play_services_update_button = 0x7f040012;
    public static final int common_google_play_services_update_text = 0x7f040009;
    public static final int common_google_play_services_update_title = 0x7f040008;
    public static final int common_signin_button_text = 0x7f040013;
    public static final int common_signin_button_text_long = 0x7f040014;
    public static final int location_client_powered_by_google = 0x7f04001b;

    public ()
    {
    }
}
